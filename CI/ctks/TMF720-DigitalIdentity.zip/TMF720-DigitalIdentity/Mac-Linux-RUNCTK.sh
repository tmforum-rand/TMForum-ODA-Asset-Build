::q#!/bin/bash

clear
#Intro


cd ./ctk && npm install && npm start