::q#!/bin/bash

clear
#Intro
echo "This will run a TMForum API CTK"
echo "In order to be able to run it, you need to have"
echo "NodeJS, NMP and Newman installed."
echo

cd ./ctk && npm install && npm start