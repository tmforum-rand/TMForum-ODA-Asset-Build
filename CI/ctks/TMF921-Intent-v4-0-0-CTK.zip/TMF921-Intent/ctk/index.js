const fs = require('fs');
const http = require('http');

var Validator = require('jsonschema').Validator;




config = JSON.parse(fs.readFileSync('../config.json'))

var pmCollection = require('./TMF921-Intent-v4.0.2.testkit.json');



headers = []
Object.keys(config['headers']).forEach(function(header){
    h = {
        "key": header,
        "value": config['headers'][header]
    }
    headers.push(h);
});
pmCollection['item'].forEach(function(i, indexi){
    i['item'].forEach(function(ii, indexii){
        pmCollection['item'][indexi]['item'][indexii]['request']['header'] = headers
    });
});



fs.writeFileSync('pmtest.json',JSON.stringify(pmCollection))
Object.keys(config['payloads']).forEach(resource => {
    var v = new Validator();
    var schema = require('./schemas/'+resource+'.schema.json');
    valid = v.validate(config['payloads'][resource]['POST']['payload'], schema);
    if (!valid.valid) {
        console.log("ERROR: Resource " + resource + " on config.json " + valid.errors[0]['message'])
        console.log('Fix your example to continue')
        process.exit(0)
    }
    if (resource == "Intent") {
        pmCollection['item'][0]['item'][0]['request']['body']['raw'] = JSON.stringify(config['payloads'][resource]['POST']['payload'])
    }
});

function waitServer(ms, server) {
    return new Promise((resolve) => {
      setTimeout(() => resolve(server), ms);
    });
}


listenOnLocalhost(config['url'])
    .then((server) => { 
        exportEnvironment(config['url'], server)
        return waitServer(10000, server)
        
    })
    .then((server) => {
        console.log("Closing server")
        server.close();
    })
    .catch((err) => {
        console.log("Error: " + err.message);
    });


function listenOnLocalhost() {
    const awaitConnection = (resolve, reject) => {
        const hostname = 'localhost';
        const port = 3000;
        const server = http.createServer((req, res) => {});
        
        server.on('request', (req, res) => {
            if (req.method == 'POST') {
                var body = '';
                req.on('data', function (data) {
                    body += data;
                }); 
                req.on('end', function () {
                    console.log("Received POST request: " + body);
                    res.writeHead(200, {'Content-Type': 'text/html'});
                    res.end('post received');

                    fs.writeFileSync('../CallbackResult.json', JSON.stringify({
                        "headers": req.headers,
                        "CallbackResult": JSON.parse(body),
                        "success": true
                    }, null,4))
                });
            }
            else {
                res.writeHead(405, {'Content-Type': 'text/html'});
                res.end('Only post requests are accepted');
            }
        });
        
        server.on('error', (err) => {  
            console.log("Error: " + err.message);
            reject(err);
        });
        
        server.listen(port, hostname, () => {
            console.log(`Callback Server running at http://${hostname}/`);
            resolve(server);
        });
    }
    return new Promise(awaitConnection);
}




function exportEnvironment(url, server) {

    var fs = require('fs');
    var environmentFile = "TMFENV-V4.0.0.postman_environment.json";
    var content = fs.readFileSync(environmentFile, "utf8");
    var envJson = JSON.parse(content);
    envJson.name = "TMForumv4";
    envJson.values.forEach(element => {
        if (element.key == "Intent") {
            element.value = config['url'];
        }
    });
    jsonData = JSON.stringify(envJson);
    fs.writeFileSync("TMFENV.json", jsonData);
    runNewman()

}

function runNewman() {
    var newman = require('newman');

    newman.run({
        collection: pmCollection,
        environment: require('./TMFENV.json'),
        insecure: true,
        reporters: ['html', 'json'],
        reporter: {
            html: {
                export: '../htmlResults.html', // If not specified, the file will be written to `newman/` in the current working directory.
                //template: './customTemplate.hbs' // optional, this will be picked up relative to the directory that Newman runs in.
            },
            json: {
                export: '../jsonResults.json'
            }
        }
    }).on('start', function (err, args) {
        console.log('running a collection...');
    }).on('done', function (err, summary) {
        if (err || summary.error) {
            if (err) {
                console.error('collection run encountered an error. ' + err);
                process.exit(2)
            }
            if (summary.error) {
                console.log("Collected run completed but with errors, please check htmlResults.html for details. Your API didn't pass the Conformance Test Kit.");
                process.exit(1)
            }

        } else {
            console.log('...Conformance Test Kit executed all the tests, check htmlResults.html and jsonResults.json for your test results.\n...If you are looking for certification, please contact TM Forum.');
            //process.exit(0)
        }
    });
}