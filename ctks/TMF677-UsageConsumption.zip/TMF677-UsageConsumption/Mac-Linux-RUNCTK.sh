clear

cd ./ctk && npm install && npm start